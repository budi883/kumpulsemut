# kumpulsemut
https://raw.githack.com/kumpul4semut/newtermux/master/key.py
